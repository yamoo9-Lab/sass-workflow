$(document).ready(function() {

    skip_nav();

    if (isPcCheck()) {
        pc_parallax();
    }

});


/* 본문 바로가기  */
function skip_nav() {
    var $doc                   = $('html, body'),
        skipContentTopPosition = $('.scrollblock.summary-area.gray').offset().top;
    $('#skip_nav a').click(function() {
        $($(this).attr('href')).attr('tabindex', '0').focus();
        $doc.animate({scrollTop: skipContentTopPosition}, 400);
        return false;
    });
}


/* 디바이스 체크 */
function isPcCheck() {
    var filter = "win16|win32|win64|mac|macintel";
    if (navigator.platform) {
        if (filter.indexOf(navigator.platform.toLowerCase()) < 0) {
            return false;
        } else {
            return true;
        }
    }
}

/* 데스크탑의 경우 scrollrama 실행 */
function pc_parallax() {

    // initialize the plugin, pass in the class selector for the sections of content (blocks)
    var scrollorama = $.scrollorama({
        blocks: '.scrollblock',
        // 서둘러 시작하는 설정(추가)
        getCracking: true
    });

    $('.scrollblock').css('position', 'absolute');
    // animate the parallaxing

    scrollorama.animate('.summary-intro .bg', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -250,
        end: 0
    })

    scrollorama.animate('.summary-intro .object01', {
        delay: 650,
        duration: 400,
        property: 'top',
        start: -550,
        end: 57
    });

    scrollorama.animate('.summary-intro .object02', {
        delay: 400,
        duration: 500,
        property: 'top',
        start: -550,
        end: 173
    });

    scrollorama.animate('.summary-intro .object03', {
        delay: 500,
        duration: 400,
        property: 'top',
        start: -550,
        end: 166
    });

    scrollorama.animate('.summary-intro .object04', {
        delay: 650,
        duration: 400,
        property: 'top',
        start: -550,
        end: 100
    });


    scrollorama.animate('#type-01 .bg', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -350,
        end: 0
    });


    scrollorama.animate('#type-01 .object01', {
        delay: 500,
        duration: 400,
        property: 'top',
        start: -550,
        end: 48
    });

    scrollorama.animate('#type-01 .object02', {
            delay: 600,
            duration: 400,
            property: 'top',
            start: -550,
            end: 150
        });


    scrollorama.animate('#type-02 .bg', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -200,
        end: 0
    });

    scrollorama.animate('#type-02 .object01', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -350,
        end: 40
    });

    scrollorama.animate('#type-02 .object02', {
        delay: 500,
        duration: 400,
        property: 'top',
        start: -350,
        end: 84
    });

    scrollorama.animate('#type-02 .object03', {
        delay: 900,
        duration: 70,
        property: 'opacity',
        start: 0,
        end: 1
    });


    scrollorama.animate('#type-03 .bg', {
        delay: 200,
        duration: 400,
        property: 'top',
        start: -200,
        end: 54
    });

    scrollorama.animate('#type-03 .object01', {
        delay: 200,
        duration: 400,
        property: 'top',
        start: -200,
        end: 0
    });

    scrollorama.animate('#type-03 .object01', {
        delay: 200,
        duration: 400,
        property: 'opacity',
        start: 0,
        end: 1
    });

    scrollorama.animate('#type-03 .object02', {
        delay: 600,
        duration: 200,
        property: 'opacity',
        start: 0,
        end: 1
    });


    scrollorama.animate('#accessibility-01 .bg', {
        delay: 200,
        duration: 400,
        property: 'top',
        start: -200,
        end: 56
    });

    scrollorama.animate('#accessibility-01 .object01', {
            delay: 400,
            duration: 600,
            property: 'top',
            start: -400,
            end: 0
        });


    scrollorama.animate('#accessibility-02 .bg', {
        delay: 300,
        duration: 400,
        property: 'top',
        start: -200,
        end: 45
    });

    scrollorama.animate('#accessibility-02 .object01', {
            delay: 400,
            duration: 600,
            property: 'top',
            start: -400,
            end: 0
        });



    scrollorama.animate('#accessibility-03 .bg', {
        delay: 300,
        duration: 400,
        property: 'top',
        start: -200,
        end: 0
    });

    scrollorama.animate('#accessibility-03 .object01', {
        delay: 400,
        duration: 600,
        property: 'top',
        start: -600,
        end: 65
    });


    scrollorama.animate('#state-01 .bg', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -200,
        end: 0
    });

    scrollorama.animate('#state-01 .object01', {
        delay: 500,
        duration: 500,
        property: 'top',
        start: -500,
        end: 42
    });


    scrollorama.animate('#state-02 .bg', {
        delay: 400,
        duration: 400,
        property: 'top',
        start: -256,
        end: 30
    });

    scrollorama.animate('#state-02 .object01', {
        delay: 600,
        duration: 400,
        property: 'top',
        start: -200,
        end: 30
    });

    scrollorama.animate('#state-02 .object02', {
        delay: 900,
        duration: 30,
        property: 'opacity',
        start: 0,
        end: 1
    });


    scrollorama.animate('#state-03 .bg', {
        delay: 200,
        duration: 400,
        property: 'top',
        start: -304,
        end: 0
    });

    scrollorama.animate('#state-03 .object01', {
        delay: 600,
        duration: 300,
        property: 'top',
        start: -350,
        end: 148
    });


}
