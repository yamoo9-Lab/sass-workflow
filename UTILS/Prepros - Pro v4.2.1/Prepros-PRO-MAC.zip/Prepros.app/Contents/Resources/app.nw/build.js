var fs = require('fs-extra');
var path = require('path');

fs.copy('app', '/cool')