/**
 * Prepros
 * (c) Subash Pathak
 * sbshpthk@gmail.com
 * License: MIT
 */

/*jshint browser: true, node: true, unused: false, globalstrict:true*/
/*global angular */

'use strict';

var prepros = angular.module('prepros', []).config([

    '$compileProvider',
    '$routeProvider',

    function ($compileProvider, $routeProvider) {

        //Routers
        $routeProvider
            .when('/home', {path: 'HOME'})
            .when('/files/:pid', {path: 'FILES'})
            .when('/files/:pid/:fid', {path: 'FILES'})
            .when('/html/:pid', {path: 'FILES', subPath: 'HTML'})
            .when('/html/:pid/:fid', {path: 'FILES', subPath: 'HTML'})
            .when('/css/:pid', {path: 'FILES', subPath: 'CSS'})
            .when('/css/:pid/:fid', {path: 'FILES', subPath: 'CSS'})
            .when('/js/:pid', {path: 'FILES', subPath: 'JS'})
            .when('/js/:pid/:fid', {path: 'FILES', subPath: 'JS'})
            .when('/project-options/:pid/:section', {path: 'PROJECT_OPTIONS'})
            .when('/log', {path: 'LOG'})
            .when('/images/:pid', {path: 'IMAGE_OPTIMIZATION'})
            .when('/images/:pid/:imgid', {path: 'IMAGE_OPTIMIZATION'})
            .when('/app-options/:section', {path: 'APP_OPTIONS'})
            .otherwise({redirectTo: '/home'});
    }]);