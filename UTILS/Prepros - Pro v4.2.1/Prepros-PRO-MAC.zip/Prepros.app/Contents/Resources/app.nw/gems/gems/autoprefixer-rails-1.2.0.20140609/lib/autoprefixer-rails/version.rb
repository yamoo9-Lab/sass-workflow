module AutoprefixerRails
  VERSION = '1.2.0.20140609'.freeze unless defined? AutoprefixerRails::VERSION
end
