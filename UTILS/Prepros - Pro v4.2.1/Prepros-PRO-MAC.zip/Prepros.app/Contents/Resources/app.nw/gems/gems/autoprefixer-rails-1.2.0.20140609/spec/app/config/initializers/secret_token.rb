App::Application.config.secret_key_base = 'test'
