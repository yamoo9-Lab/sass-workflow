App::Application.routes.draw do
  root to: 'css#test'
end
