Rails.application.config.assets.css_compressor = nil
