module Bourbon
  class Engine < Rails::Engine
    # auto wire
  end
end
