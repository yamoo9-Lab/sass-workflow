require "bitters/version"
require "bitters/generator"

module Bitters
  # Your code goes here...
end
