/* 루트 디렉토리 설정 -------------------------- */
var root = 'www';

/*! 환경설정 모듈 정의/출력 © yamoo9.net, 2015 */
module.exports = {

	'root': root,

	// Browser-sync 옵션
	// http://www.browsersync.io/docs/options/
	'browserSync': {
		'server'  : [ root ],
		'port'    : 9090,
		'notify'  : false,
	},

	// Sass 엔진 선택: 'node' / 'ruby' / 'compass'
	'sass_engine': process.env.sass || 'node',

	// Node Sass 설정
	'sass': {
		'src': root + '/sass/**/*.scss',
		'dest': root + '/css',
		'options': {
			// compact, compressed, nested, expanded
			'outputStyle' : 'expanded',
		}
	},

	// Ruby Sass 설정
	'ruby_sass': {
		'src': root + '/sass/',
		'dest': root + '/css',
		'options': {
			// 옵션: Git Bash or Terminal ⇒ sass -h
			'defaultEncoding'  : 'UTF-8',    // Windows 환경에서 CP949 오류 발생 시
			'style'            : 'expanded', // compact, compressed, nested, expanded
			'sourcemap'        : true,
			'compass'          : true,
			'require'          : ['susy'],
			// 'no-cache'         : true
		}
	},

	// Compass 설정
	'compass' : {
		'src': root + '/sass/**/*',
		'dest': root + '/css',
		'options': {
			'style'   : 'expanded',
			'css'     : root + '/css',
			'sass'    : root + '/sass',
			'image'   : root + '/images',
			'require' : ['susy']
		}
	},

	// Sourcemap 설정
	'ruby_sass_sourcemaps': {
		'dir': 'maps',
		'options': {
			'includeContent' : false,
			'sourceRoot'     : 'source',
		},
	},

	// 브라우저 리스트 참고 URL
	// https://github.com/ai/browserslist#queries
	'autoprefixer': [
		'> 1%',
		'last 2 versions'
	]

};